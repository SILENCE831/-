from fastapi import FastAPI, Depends, HTTPException, status, Body
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from datetime import timedelta
import models
import schemas
import auth
from database import engine, get_db
from typing import List
from schemas import UserDeviceBindRequest

# Ensure tables are created
models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="Fan API - Mimicking C# API")

# Device endpoints
@app.post("/devices/", response_model=schemas.UserDevice)
def create_device(
    device: schemas.UserDeviceCreate,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    db_device = models.UserDevice(**device.dict(), user_id=current_user.id)
    db.add(db_device)
    db.commit()
    db.refresh(db_device)
    return db_device

@app.get("/devices/", response_model=List[schemas.UserDevice])
def read_devices(
    skip: int = 0,
    limit: int = 100,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    devices = db.query(models.UserDevice).filter(
        models.UserDevice.user_id == current_user.id
    ).offset(skip).limit(limit).all()
    return devices

@app.get("/devices/{device_id}", response_model=schemas.UserDevice)
def read_device(
    device_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    device = db.query(models.UserDevice).filter(
        models.UserDevice.device_id == device_id,
        models.UserDevice.user_id == current_user.id
    ).first()
    if device is None:
        raise HTTPException(status_code=404, detail="Device not found")
    return device

@app.put("/devices/{device_id}", response_model=schemas.UserDevice)
def update_device(
    device_id: str,
    device_update: schemas.UserDeviceBase,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    device = db.query(models.UserDevice).filter(
        models.UserDevice.device_id == device_id,
        models.UserDevice.user_id == current_user.id
    ).first()
    if device is None:
        raise HTTPException(status_code=404, detail="Device not found")
    
    for key, value in device_update.dict().items():
        setattr(device, key, value)
    
    db.commit()
    db.refresh(device)
    return device

@app.delete("/devices/{device_id}")
def delete_device(
    device_id: str,
    db: Session = Depends(get_db),
    current_user: models.User = Depends(auth.get_current_user)
):
    device = db.query(models.UserDevice).filter(
        models.UserDevice.device_id == device_id,
        models.UserDevice.user_id == current_user.id
    ).first()
    if device is None:
        raise HTTPException(status_code=404, detail="Device not found")
    
    db.delete(device)
    db.commit()
    return {"message": "Device deleted successfully"}

# --- Mimicking C# API Endpoints ---

@app.post("/User/VerifyUser", response_model=schemas.CommonResult)
def verify_user(postData: schemas.UserVerifyRequest, db: Session = Depends(get_db)):
    # In C# this checked UserName, mimicking that behavior
    is_exists = db.query(models.User).filter(models.User.username == postData.UserName).first() is not None
    if is_exists:
        return schemas.CommonResult(Status=False, Message="用户已存在")
    else:
        return schemas.CommonResult(Status=True, Message="请输入密码！")

# Mimicking C# default POST /User for registration
@app.post("/User", response_model=schemas.CommonResult)
def register_user(postData: schemas.UserRegisterRequest, db: Session = Depends(get_db)):
    # Check if user exists by UserName (mimicking C#)
    is_exists = db.query(models.User).filter(models.User.username == postData.UserName).first() is not None

    if is_exists:
        return schemas.CommonResult(Status=False, Message="用户已存在")
    else:
        # Create user. Note: The Python model requires email. Using a placeholder.
        # The C# code only showed UserName and Password for registration.
        hashed_password = auth.get_password_hash(postData.Password)
        db_user = models.User(
            username=postData.UserName,
            email=f"{postData.UserName}@example.com", # Placeholder email
            hashed_password=hashed_password
        )
        db.add(db_user)
        db.commit()
        # db.refresh(db_user) # C# didn't return the user object here, just success message

        return schemas.CommonResult(Status=True, Message="创建成功！")

# Mimicking C# POST /User/Login
@app.post("/User/Login", response_model=schemas.CommonResult)
def login_user(postData: schemas.UserLoginRequest, db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.username == postData.UserName).first()

    if not user:
         return schemas.CommonResult(Status=False, Message="用户名不存在") # Assuming C# would return something like this

    # Verify password
    if not auth.verify_password(postData.Password, user.hashed_password):
        return schemas.CommonResult(Status=False, Message="密码错误") # Assuming C# would return something like this

    # If login is successful, C# snippet was incomplete. 
    # Let's return a success message and maybe some user data in CommonResult.Data
    # Note: In a real app, you'd likely return a JWT token here for subsequent requests.
    # But to mimic CommonResult return, we'll just return success status and user ID/username in Data
    
    user_data = {"UserId": user.id, "UserName": user.username}

    return schemas.CommonResult(Status=True, Message="登录成功！", Data=user_data) 

@app.post("/UserDevice/IsDeviceOnline")
def is_device_online(postData: schemas.DeviceOnlineRequest = Body(...), db: Session = Depends(get_db)):
    device = db.query(models.UserDevice).filter(models.UserDevice.device_id == postData.deviceId).first()
    if device:
        return {"Status": True, "Message": "设备在线", "Data": {"deviceId": device.device_id, "isOnline": device.is_active}}
    else:
        return {"Status": False, "Message": "设备不存在", "Data": None}

@app.post("/UserDevice")
def bind_device(postData: UserDeviceBindRequest = Body(...), db: Session = Depends(get_db)):
    user = db.query(models.User).filter(models.User.username == postData.UserName).first()
    if not user:
        return {"status": False, "message": "用户不存在"}
    device = db.query(models.UserDevice).filter(models.UserDevice.device_id == postData.DeviceUUID).first()
    if device:
        return {"status": False, "message": "设备已存在"}
    db_device = models.UserDevice(
        user_id=user.id,
        device_id=postData.DeviceUUID,
        device_name=postData.DeviceName,
        device_type="BLE",
        is_active=True
    )
    db.add(db_device)
    db.commit()
    db.refresh(db_device)
    return {"status": True, "message": "设备绑定成功"} 