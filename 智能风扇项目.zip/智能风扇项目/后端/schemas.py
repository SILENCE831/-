from pydantic import BaseModel, EmailStr
from typing import Optional, List, Any
from datetime import datetime

class CommonResult(BaseModel):
    Status: bool
    Message: str
    Data: Optional[Any] = None

class UserVerifyRequest(BaseModel):
    UserName: str

class UserRegisterRequest(BaseModel):
    UserName: str
    Password: str

class UserLoginRequest(BaseModel):
    UserName: str
    Password: str

class UserBase(BaseModel):
    username: str
    email: EmailStr

class UserCreate(UserBase):
    password: str

class User(UserBase):
    id: int
    is_active: bool
    created_at: datetime

    class Config:
        orm_mode = True

class Token(BaseModel):
    access_token: str
    token_type: str

class TokenData(BaseModel):
    username: Optional[str] = None

class UserDeviceBase(BaseModel):
    device_name: str
    device_type: str

class UserDeviceCreate(UserDeviceBase):
    device_id: str

class UserDevice(UserDeviceBase):
    id: int
    user_id: int
    device_id: str
    is_active: bool
    created_at: datetime
    last_connected: Optional[datetime]

    class Config:
        orm_mode = True 

class DeviceOnlineRequest(BaseModel):
    deviceId: str

class UserDeviceBindRequest(BaseModel):
    UserName: str
    DeviceUUID: str
    DeviceName: str 