# Fan API - Python Backend

这是一个使用Python FastAPI框架重写的Fan API后端项目。该项目提供了用户认证和设备管理的RESTful API接口。

## 功能特性

- 用户认证和授权
- 用户管理
- 设备管理
- SQL Server数据库支持

## 技术栈

- FastAPI
- SQLAlchemy
- PyMSSQL
- Pydantic
- Python-Jose (JWT)
- Passlib (密码哈希)

## 安装

1. 确保已安装Python 3.8或更高版本
2. 安装依赖包：
   ```bash
   pip install -r requirements.txt
   ```

## 配置

1. 复制`.env.example`文件为`.env`
2. 在`.env`文件中配置以下环境变量：
   - DATABASE_URL: SQL Server数据库连接字符串
   - SECRET_KEY: JWT密钥
   - ALGORITHM: JWT算法（默认HS256）
   - ACCESS_TOKEN_EXPIRE_MINUTES: 访问令牌过期时间（分钟）

## 运行

```bash
uvicorn main:app --reload
```

服务器将在 http://localhost:8000 启动

## API文档

启动服务器后，可以访问以下地址查看API文档：
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## API端点

### 认证
- POST /token - 获取访问令牌

### 用户
- POST /users/ - 创建新用户
- GET /users/me/ - 获取当前用户信息

### 设备
- POST /devices/ - 创建设备
- GET /devices/ - 获取设备列表
- GET /devices/{device_id} - 获取特定设备
- PUT /devices/{device_id} - 更新设备
- DELETE /devices/{device_id} - 删除设备

## 数据库

项目使用SQL Server数据库。数据库表结构将在首次运行时自动创建。

## 安全

- 所有密码都使用bcrypt进行哈希处理
- 使用JWT进行身份验证
- API端点使用OAuth2密码流进行保护 