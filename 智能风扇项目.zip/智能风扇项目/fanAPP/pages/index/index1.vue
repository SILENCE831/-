<template>
	<view>
		<view class="content">
			<image class="logo" src="/static/ble.png"></image>
		</view>
		<view class="text-area">
			<text class="title">{{title}}</text>
		</view>
		<scroll-view scroll-y class="list">
			<text class="title">{{title2}}</text>
			<view>
				<view v-for="(item,index) in devicelist" :item="item" :index="index" :key="item.id"
					@tap="wificonnected()" class="connectedlist">
					<text class="connected">{{item}}</text>
				</view>
			</view>
		</scroll-view>
		<scroll-view scroll-y class="list">
			<text class="title">{{title1}}</text>
			<view>
				<view v-for="(item,index) in servicelist" :item="item" :index="index" :key="item.id"
					@tap="onDeviceClick(item)" class="connectedlist">
					<text class="connected">{{item.name}}</text>
				</view>
			</view>
		</scroll-view>
		<view class="uni-padding-wrap uni-common-mt">
			<view class="uni-btn-v">
				<button type="primary" @tap="toBle">
					添加蓝牙
				</button>
				<button type="primary" @tap="toWIFI">
					添加WIFI
				</button>
			</view>
		</view>
	</view>
</template>

<script>
	import config from '@/config.js';
	export default {
		data() {
			return {
				title: 'Hello,',
				title1: '已配对蓝牙列表',
				title2: 'WIFI在线设备',
				servicelist: [],
				devicelist: [],
				name: [],
				deviceCheckTimer: null,
				isChecking: false
			}
		},
		onLoad() {
			this.initializeDevice();
		},
		onUnload() {
			// 清除定时器
			if (this.deviceCheckTimer) {
				clearInterval(this.deviceCheckTimer);
				this.deviceCheckTimer = null;
			}
		},
		methods: {
			initializeDevice() {
				var that = this;
				this.condition == null;
				var tmpDeviceId = uni.getStorageSync('deviceId');
				console.log('Stored deviceId:', tmpDeviceId);
				
				// 安全地获取设备ID
				let deviceId = null;
				if (tmpDeviceId && Array.isArray(tmpDeviceId) && tmpDeviceId.length > 0) {
					deviceId = tmpDeviceId[0].deviceId;
				}
				
				uni.setStorageSync("current", this.condition);
				
				// 只有在有设备ID时才启动轮询
				if (deviceId) {
					// 清除可能存在的旧定时器
					if (this.deviceCheckTimer) {
						clearInterval(this.deviceCheckTimer);
					}
					
					// 获取wifi在线设备
					this.deviceCheckTimer = setInterval(() => {
						if (this.isChecking) return; // 防止重复请求
						
						this.isChecking = true;
						uni.request({
							url: config.hostUrl + '/UserDevice/IsDeviceOnline',
							method: "POST",
							data: {
								deviceId: deviceId
							},
							success: res => {
								if (res.data.Status === true) {
									that.devicelist = [res.data.Data];
									console.log('设备在线');
								} else {
									that.devicelist = [];
									console.log('设备离线');
								}
							},
							fail: err => {
								console.log('设备状态检查失败:', err);
							},
							complete: () => {
								that.isChecking = false;
							}
						});
					}, 5000);
				}
				
				// 获取已配对设备列表
				this.servicelist = uni.getStorageSync('device') || [];
				this.servicelist.forEach((item, index) =>
					console.log(item.name, index));

				//初始化蓝牙模块
				uni.openBluetoothAdapter({
					success: (res) => {
						uni.getBluetoothAdapterState({
							success: (res1) => {
								console.log('本机蓝牙已打开');
							},
							fail() {
								uni.showToast({
									icon: 'none',
									title: '请打开蓝牙'
								});
							}
						});
					},
					fail: (errMsg) => {
						console.log('蓝牙初始化失败:', errMsg);
						uni.showToast({
							icon: 'none',
							title: '蓝牙初始化失败'
						});
					}
				});
			},
			reNew(){
				location.reload();
			},
			onDeviceClick(item) {
				console.log(item.name);
				console.log('到位了');
				var tmpDeviceId = uni.getStorageSync('deviceId');
				let deviceId = null;
				
				// 安全地获取设备ID
				if (tmpDeviceId && Array.isArray(tmpDeviceId) && tmpDeviceId.length > 0) {
					deviceId = tmpDeviceId[0].deviceId;
				}
				
				if (!deviceId) {
					uni.showToast({
						icon: 'none',
						title: '未找到设备ID'
					});
					return;
				}
				
				console.log(deviceId);
				uni.createBLEConnection({
					deviceId,
					success(res) {
						console.log(res)
						console.log("蓝牙连接成功")
						uni.showToast({
							icon: "success",
							duration: 1000,
						})
						uni.navigateTo({
							url: '../control/control',
							success() {
								console.log('跳转成功');
							},
							fail(res) {
								console.log('跳转失败');
							}
						})
					},
					fail(res) {
						console.log("蓝牙连接失败", res);
						if (res.errCode == -1) {
							uni.navigateTo({
								url: '../control/control',
								success() {
									console.log('跳转成功');
								},
								fail(res) {
									console.log('跳转失败');
								}
							})
						}
					}
				})
			},
			toBle() {
				uni.navigateTo({
					url: '../API/bluetooth',
					success() {
						console.log('跳转成功');
					},
					fail(res) {
						console.log('跳转失败');
					}
				})
			},
			toWIFI() {
				uni.navigateTo({
					url: '../WIFI/wifi',
					success() {
						console.log('跳转成功');
					},
					fail(res) {
						console.log('跳转失败');
					}
				})
			},
			wificonnected() {
				uni.navigateTo({
					url: '../control/wificontrol',
					success() {
						console.log('跳转成功');
					},
					fail(res) {
						console.log('跳转失败');
					}
				})
			}
		}
	}
</script>

<style>
	.content {
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.logo {
		height: 200rpx;
		width: 200rpx;
		margin-top: 200rpx;
		margin-left: auto;
		margin-right: auto;
		margin-bottom: 50rpx;
	}

	.text-area {
		display: flex;
		justify-content: center;
	}

	.list {
		height: 300rpx;
		margin: 20rpx;
		padding: 20rpx;
		background-color: #f8f8f8;
		border-radius: 10rpx;
	}

	.connectedlist {
		padding: 20rpx;
		border-bottom: 1px solid #eee;
	}

	.connected {
		font-size: 28rpx;
		color: #333;
	}

	.title {
		font-size: 36rpx;
		color: #333;
		margin-bottom: 20rpx;
	}
</style>
