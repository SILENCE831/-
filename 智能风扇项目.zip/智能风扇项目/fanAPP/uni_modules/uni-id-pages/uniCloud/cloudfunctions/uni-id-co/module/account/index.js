module.exports = {
  updatePwd: require('./update-pwd'),
  resetPwdBySms: require('./reset-pwd-by-sms'),
  closeAccount: require('./close-account'),
  getAccountInfo: require('./get-account-info')
}
