/**
 * 发送邮箱链接，可用于登录、注册、绑定邮箱、修改密码等操作
 * @tutorial
 * @param {Object} params
 * @param {String} params.email     邮箱
 * @param {String} params.scene     使用场景
 * @returns
 */
module.exports = async function (params = {}) {
  // 此接口暂未实现，欢迎向我们提交pr
  throw new Error('api[sendEmailLink] is not yet implemented')
}
