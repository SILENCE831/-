<!-- 账号注册页 -->
<template>
	<view class="uni-content">
		<uni-forms ref="form" :value="formData" :rules="rules" validate-trigger="submit" err-show-type="toast">
			<uni-forms-item name="username" required>
				<uni-easyinput :inputBorder="false" :focus="focusUsername"
					@blur="bindTextAreaBlur" class="input-box" placeholder="请输入用户名"
					v-model="formData.username" trim="both" />
			</uni-forms-item>
			<uni-forms-item name="password" v-model="formData.password" required>
				<uni-easyinput :inputBorder="false" :focus="focusPassword" @blur="focusPassword = false"
					class="input-box" maxlength="20" placeholder="请输入6-20位密码" type="password"
					v-model="formData.password" trim="both" />
			</uni-forms-item>
			<uni-forms-item name="password2" v-model="formData.password2" required>
				<uni-easyinput :inputBorder="false" :focus="focusPassword2" @blur="focusPassword2 =false"
					class="input-box" placeholder="再次输入密码" maxlength="20" type="password" v-model="formData.password2"
					trim="both" />
			</uni-forms-item>
			<button class="uni-btn" type="primary" @click="submit">注册</button>
			<button class="uni-btn" type="primary" @click="navigateBack">返回</button>
		</uni-forms>
	</view>
</template>

<script>
	import rules from '@/uni_modules/uni-id-pages/pages/register/validator.js';
	import mixin from '@/uni_modules/uni-id-pages/common/login-page.mixin.js';
	import config from '@/config.js';
	import api from '@/common/api.js';
	
	export default {
		mixins: [mixin],
		data() {
			return {
				formData: {
					username: "",
					nickname: "",
					password: "",
					password2: "",
				},
				rules,
				focusUsername: false,
				focusNickname: false,
				focusPassword: false,
				focusPassword2: false
			}
		},
		onReady() {
			this.$refs.form.setRules(this.rules)
		},
		methods: {
			async bindTextAreaBlur() {
				try {
					const res = await api.user.checkUsername({
						username: this.formData.username
					});
					
					if (res.available) {
						console.log("用户名可用");
					} else {
						uni.showToast({
							icon: 'none',
							title: '用户名已存在',
						});
					}
				} catch (error) {
					uni.showToast({
						icon: 'error',
						title: error.message || '验证失败'
					});
				}
			},
			/**
			 * 触发表单提交
			 */
			async submit() {
				try {
					await this.$refs.form.validate();
					
					// 检查两次密码是否一致
					if (this.formData.password !== this.formData.password2) {
						return uni.showToast({
							icon: 'none',
							title: '两次输入的密码不一致'
						});
					}
					
					// 注册用户
					await api.user.register({
						username: this.formData.username,
						password: this.formData.password,
						nickname: this.formData.nickname
					});
					
					uni.showToast({
						title: '注册成功',
						duration: 1000,
						success() {
							setTimeout(() => {
								uni.navigateBack();
							}, 1000);
						}
					});
				} catch (error) {
					uni.showToast({
						icon: 'error',
						title: error.message || '注册失败'
					});
				}
			},
			navigateBack() {
				uni.navigateBack();
			}
		}
	}
</script>

<style lang="scss">
	@import "@/uni_modules/uni-id-pages/common/login-page.scss";

	.uni-content {
		margin-top: 15px;
	}

	.uni-content ::v-deep .uni-forms-item__label {
		position: absolute;
		left: -15px;
	}

	button {
		margin-top: 15px;
	}
</style>