<template>
	<view class="uni-content">
	<text class="title title-box">账号密码登录</text>
	<uni-forms>
		<uni-forms-item name="username">
			<uni-easyinput :focus="focusUsername" @blur="focusUsername = false" class="input-box" :inputBorder="false" v-model="username" placeholder="请输入用户名">
			</uni-easyinput>
		</uni-forms-item>
		<uni-forms-item name="password">
			<uni-easyinput :focus="focusPassword" @blur="focusPassword = false" class="input-box" clearable type="password" :inputBorder="false" v-model="password" placeholder="请输入密码">
			</uni-easyinput>
		</uni-forms-item>
	</uni-forms>
	<view class="link-box">
		<text class="link" @click="toRegister">注册账号</text>
	</view>
	<button class="uni-btn" type="primary" @click="pwdLogin">登录</button>
	<button class="uni-btn" type="primary" @click="navigateBack">返回</button>
	</view>
</template>

<script>
	import config from '@/config.js';
	import api from '@/common/api.js';
	
	export default {
		data() {
			return {
				"password": "",
				"username": "",
				"focusUsername": false,
				"focusPassword": false,
			}
		},
		methods: {
			/**
			 * 密码登录
			 */
			async pwdLogin() {
				if(!this.password.length){
					this.focusPassword = true
					return uni.showToast({
						title: '请输入密码',
						icon: 'none'
					});
				}
				if(!this.username.length){
					this.focusUsername = true
					return uni.showToast({
						title: '请输入用户名',
						icon: 'none'
					});
				}
				
				try {
					const res = await api.user.login({
						username: this.username,
						password: this.password
					});
					
					// 保存用户信息
					uni.setStorageSync("UserName", this.username);
					
					uni.showToast({
						title: '登录成功',
						duration: 1000,
						success() {
							uni.navigateTo({
								url: '../index/index1'
							});
						}
					});
				} catch (error) {
					uni.showToast({
						icon: 'error',
						title: error.message || '登录失败'
					});
				}
			},
			/* 前往注册 */
			toRegister() {
				uni.navigateTo({
					url: '../Register/Register'
				});
			},
			navigateBack() {
				uni.navigateBack();
			}
		},
	}
</script>

<style lang="scss" scoped>
	@import "@/uni_modules/uni-id-pages/common/login-page.scss";

	.forget{
		font-size: 12px;
		color: #8a8f8b;
	}

	.link-box {
		/* #ifndef APP-NVUE */
		display: flex;
		/* #endif */
		flex-direction: row;
		justify-content: space-between;
		margin-top: 20px;
	}

	.link {
		font-size: 12px;
	}
</style>