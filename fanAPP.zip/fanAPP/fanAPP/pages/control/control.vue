<template>
	<view>
		<page-head :title="title"></page-head>
		<view class="uni-padding-wrap uni-common-mt">
			<view class="uni-btn-v">
				<button type="primary" :disabled="disabled[11]" @click="toBind">
					绑定设备
				</button>
				<button type="primary" @click="toWIFI">
					WIFI连接
				</button>
				<button type="primary" :disabled="disabled[11]" @click="openGear">
					打开风扇
				</button>
				<button type="primary" :disabled="disabled[11]" @click="oneGear">
					一档
				</button>
				<button type="primary" :disabled="disabled[11]" @click="twoGear">
					二档
				</button>
				<button type="primary" :disabled="disabled[11]" @click="threeGear">
					三档
				</button>
				<button type="primary" :disabled="disabled[11]" @click="offGear">
					关闭风扇
				</button>
				<button type="primary" :disabled="disabled[11]" @click="showScheduleDialog">
					定时任务
				</button>
				<button type="primary" :disabled="disabled[11]" @click="showSensorDialog">
					传感器数据
				</button>
			</view>
		</view>
		
		<!-- 定时任务弹窗 -->
		<uni-popup ref="schedulePopup" type="dialog">
			<uni-popup-dialog
				title="设置定时任务"
				:before-close="true"
				@confirm="confirmSchedule"
				@close="closeSchedule"
			>
				<view class="schedule-form">
					<view class="form-item">
						<text>选择时间:</text>
						<picker mode="selector" :value="[scheduleHourIndex, scheduleMinuteIndex, scheduleSecondIndex]" :range="[hoursArray, minutesArray, secondsArray]" @change="onTimeChange">
							<view class="picker-value">{{hoursArray[scheduleHourIndex]}}:{{minutesArray[scheduleMinuteIndex]}}:{{secondsArray[scheduleSecondIndex]}}</view>
						</picker>
					</view>
					<view class="form-item">
						<text>选择操作:</text>
						<picker :range="operationOptions" :value="operationIndex" @change="onOperationChange">
							<view class="picker-value">{{operationOptions[operationIndex] || '请选择操作'}}</view>
						</picker>
					</view>
					<view class="form-item" v-if="operationIndex === 2">
						<text>选择风速:</text>
						<picker :range="speedOptions" :value="speedIndex" @change="onSpeedChange">
							<view class="picker-value">{{speedOptions[speedIndex] || '请选择风速'}}</view>
						</picker>
					</view>
				</view>
			</uni-popup-dialog>
		</uni-popup>

		<!-- 传感器数据弹窗 -->
		<uni-popup ref="sensorPopup" type="dialog">
			<uni-popup-dialog
				title="传感器数据"
				:before-close="true"
				@close="closeSensor"
			>
				<view class="sensor-data">
					<view class="data-item">
						<text class="label">温度:</text>
						<text class="value">{{sensorData.temperature}}°C</text>
					</view>
					<view class="data-item">
						<text class="label">湿度:</text>
						<text class="value">{{sensorData.humidity}}%</text>
					</view>
					<view class="data-item">
						<text class="label">体感温度:</text>
						<text class="value">{{sensorData.heatIndex}}°C</text>
					</view>
					<view class="auto-control">
						<text class="label">自动控制:</text>
						<switch :checked="autoControlEnabled" @change="toggleAutoControl" />
					</view>
					<view class="threshold-settings" v-if="autoControlEnabled">
						<view class="threshold-item">
							<text>开启阈值:</text>
							<input type="number" v-model="autoControlSettings.heatIndexOn" @change="updateAutoControlSettings" />
							<text>°C</text>
						</view>
						<view class="threshold-item">
							<text>关闭阈值:</text>
							<input type="number" v-model="autoControlSettings.heatIndexOff" @change="updateAutoControlSettings" />
							<text>°C</text>
						</view>
						<view class="speed-setting">
							<text>自动风速:</text>
							<picker :range="speedOptions" :value="autoControlSettings.speed - 1" @change="onAutoSpeedChange">
								<view class="picker-value">{{speedOptions[autoControlSettings.speed - 1] || '请选择风速'}}</view>
							</picker>
						</view>
					</view>
				</view>
			</uni-popup-dialog>
		</uni-popup>
	</view>
</template>

<script>
	import config from '@/config.js';
	import api from '@/common/api.js';
	
	export default {
		data() {
			return {
				title: '风扇控制',
				disabled: [false, false, false, true, true, true, true, true, true, true, true, false],
				newDeviceLoad: false,
				searchLoad: false,
				maskShow: false,
				equipment: '',
				adapterState: {
					discovering: false,
					available: false
				},
				connected: false,
				showMaskType: 'device',
				servicesData: '',
				characteristicsData: '',
				valueChangeData: {},
				isStop: true,
				list: [],
				// 定时任务相关数据
				scheduleHourIndex: 0,
				scheduleMinuteIndex: 0,
				scheduleSecondIndex: 0,
				hoursArray: Array.from({ length: 24 }, (_, i) => (i < 10 ? '0' : '') + i),
				minutesArray: Array.from({ length: 60 }, (_, i) => (i < 10 ? '0' : '') + i),
				secondsArray: Array.from({ length: 60 }, (_, i) => (i < 10 ? '0' : '') + i),
				operationOptions: ['开启风扇', '关闭风扇', '设置风速'],
				operationIndex: 0,
				speedOptions: ['一档', '二档', '三档'],
				speedIndex: 0,
				// 传感器数据相关
				sensorData: {
					temperature: 0,
					humidity: 0,
					heatIndex: 0
				},
				autoControlEnabled: false,
				autoControlSettings: {
					heatIndexOn: 26.0,
					heatIndexOff: 24.0,
					speed: 3
				},
				sensorUpdateInterval: null
			};
		},
		onLoad(option) {
			this.equipment = uni.getStorageSync('deviceId');
			this.servicesData = uni.getStorageSync('serviceId');
			this.characteristicsData = uni.getStorageSync('characteristicId');
		},
		methods: {
			// Convert string to UTF-8 bytes
			stringToUtf8Bytes(str) {
				const utf8 = [];
				for (let i = 0; i < str.length; i++) {
					let charcode = str.charCodeAt(i);
					if (charcode < 0x80) utf8.push(charcode);
					else if (charcode < 0x800) {
						utf8.push(0xc0 | (charcode >> 6),
								0x80 | (charcode & 0x3f));
					}
					else if (charcode < 0xd800 || charcode >= 0xe000) {
						utf8.push(0xe0 | (charcode >> 12),
								0x80 | ((charcode>>6) & 0x3f),
								0x80 | (charcode & 0x3f));
					}
					else {
						i++;
						charcode = 0x10000 + (((charcode & 0x3ff)<<10)
									| (str.charCodeAt(i) & 0x3ff));
						utf8.push(0xf0 | (charcode >>18),
								0x80 | ((charcode>>12) & 0x3f),
								0x80 | ((charcode>>6) & 0x3f),
								0x80 | (charcode & 0x3f));
					}
				}
				return new Uint8Array(utf8);
			},
			/**
			 * 打开风扇
			 */
			openGear() {
				var tmp = {
					command: 3,
					method: true
				};
				this.writeBLECharacteristicValue(tmp);
			},
			/**
			 * 一档
			 */
			oneGear() {
				var tmp = {
					command: 4,
					speed: 1
				};
				this.writeBLECharacteristicValue(tmp);
			},
			/**
			 * 二档
			 */
			twoGear() {
				var tmp = {
					command: 4,
					speed: 2
				};
				this.writeBLECharacteristicValue(tmp);
			},
			/**
			 * 三档
			 */
			threeGear() {
				var tmp = {
					command: 4,
					speed: 3
				};
				this.writeBLECharacteristicValue(tmp);
			},
			/**
			 * off档
			 */
			offGear() {
				var tmp = {
					command: 3,
					method: false
				};
				this.writeBLECharacteristicValue(tmp);
			},
			/**
			 * 写入数据
			 */
			writeBLECharacteristicValue(tmp) {
				let deviceId = this.equipment[0].deviceId;
				let serviceId = this.servicesData[0].uuid;
				let characteristicId = this.characteristicsData[0].uuid;
				
				// 确保 JSON 格式完全匹配设备期望的格式
				var jsonstr1 = JSON.stringify(tmp, null, 0);
				console.log("准备发送的JSON数据:", jsonstr1);
				var buffer = this.stringToUtf8Bytes(jsonstr1).buffer;
				console.log("转换后的字节数组:", new Uint8Array(buffer));
				
				uni.writeBLECharacteristicValue({
					deviceId,
					serviceId,
					characteristicId,
					value: buffer,
					success: (res) => {
						console.log("写入成功，完整数据:", {
							deviceId,
							serviceId,
							characteristicId,
							sentData: jsonstr1,
							rawBytes: Array.from(new Uint8Array(buffer))
						});
					},
					fail: (res) => {
						console.log("写入失败，错误信息:", res);
						setTimeout(() => {
							this.writeBLECharacteristicValue(tmp);
						}, 100);
					}
				});
			},
			toWIFI() {
				uni.navigateTo({
					url: '../WIFI/wifi'
				});
			},
			async toBind() {
				try {
					const deviceList = uni.getStorageSync('DeviceList') || [];
					const deviceId = this.equipment[0].deviceId;
					
					// 检查设备是否已绑定
					if (deviceList.includes(deviceId)) {
						return uni.showToast({
							title: "设备已经注册",
							duration: 1000
						});
					}
					
					// 绑定设备
					await api.device.add({
						device_id: deviceId,
						device_name: this.equipment[0].name
					});
					
					// 更新本地设备列表
					deviceList.push(deviceId);
					uni.setStorageSync('DeviceList', deviceList);
					
					uni.showToast({
						title: '设备绑定成功',
						icon: 'success',
						duration: 1000
					});
				} catch (error) {
					uni.showToast({
						title: error.message || '设备绑定失败',
						icon: 'error',
						duration: 1000
					});
				}
			},
			// 显示定时任务弹窗
			showScheduleDialog() {
				this.$refs.schedulePopup.open();
			},
			
			// 时间选择器变化
			onTimeChange(e) {
				const [hourIndex, minuteIndex, secondIndex] = e.detail.value;
				this.scheduleHourIndex = hourIndex;
				this.scheduleMinuteIndex = minuteIndex;
				this.scheduleSecondIndex = secondIndex;
			},
			
			// 操作选择器变化
			onOperationChange(e) {
				this.operationIndex = e.detail.value;
			},
			
			// 风速选择器变化
			onSpeedChange(e) {
				this.speedIndex = e.detail.value;
			},
			
			// 确认定时任务
			confirmSchedule() {
				const now = new Date();
				const hours = parseInt(this.hoursArray[this.scheduleHourIndex], 10);
				const minutes = parseInt(this.minutesArray[this.scheduleMinuteIndex], 10);
				const seconds = parseInt(this.secondsArray[this.scheduleSecondIndex], 10);
				
				const targetDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hours, minutes, seconds);
				
				// 如果选择的时间已经过去，设置为明天
				if (targetDate < now) {
					targetDate.setDate(targetDate.getDate() + 1);
				}
				
				// 转换为Unix时间戳（秒）
				const targetTimestamp = Math.floor(targetDate.getTime() / 1000);
				
				// 构建定时任务命令
				let operation = '';
				let speed = 0;
				
				switch (this.operationIndex) {
					case 0: // 开启风扇
						operation = 'ON';
						break;
					case 1: // 关闭风扇
						operation = 'OFF';
						break;
					case 2: // 设置风速
						operation = 'SET_SPEED';
						speed = this.speedIndex + 1;
						break;
				}
				
				// 构建发送给设备的命令
				const command = {
					command: 6, // 定时任务命令
					targetTimestamp: targetTimestamp,
					operation: operation,
					speed: speed,
					appTimestamp: Math.floor(Date.now() / 1000) // 当前时间戳
				};
				
				// 发送命令
				this.writeBLECharacteristicValue(command);
				
				// 关闭弹窗
				this.$refs.schedulePopup.close();
				
				// 显示成功提示
				uni.showToast({
					title: '定时任务设置成功',
					icon: 'success'
				});
			},
			
			// 关闭定时任务弹窗
			closeSchedule() {
				// 重置表单数据
				this.scheduleHourIndex = 0;
				this.scheduleMinuteIndex = 0;
				this.scheduleSecondIndex = 0;
				this.operationIndex = 0;
				this.speedIndex = 0;
			},

			// 显示传感器数据弹窗
			showSensorDialog() {
				this.$refs.sensorPopup.open();
				// 开始定时更新传感器数据
				this.startSensorUpdates();
			},

			// 关闭传感器数据弹窗
			closeSensor() {
				this.$refs.sensorPopup.close();
				// 停止定时更新
				this.stopSensorUpdates();
			},

			// 开始定时更新传感器数据
			startSensorUpdates() {
				// 每5秒更新一次数据
				this.sensorUpdateInterval = setInterval(() => {
					this.updateSensorData();
				}, 5000);
				// 立即执行一次
				this.updateSensorData();
			},

			// 停止定时更新
			stopSensorUpdates() {
				if (this.sensorUpdateInterval) {
					clearInterval(this.sensorUpdateInterval);
					this.sensorUpdateInterval = null;
				}
			},

			// 更新传感器数据
			updateSensorData() {
				// 构建请求命令
				const command = {
					command: 8, // 新增命令类型：获取传感器数据
					appTimestamp: Math.floor(Date.now() / 1000)
				};
				this.writeBLECharacteristicValue(command);
			},

			// 切换自动控制
			toggleAutoControl(e) {
				this.autoControlEnabled = e.detail.value;
				// 发送自动控制设置到设备
				const command = {
					command: 7,
					auto_enabled: this.autoControlEnabled,
					heat_index_on: parseFloat(this.autoControlSettings.heatIndexOn),
					heat_index_off: parseFloat(this.autoControlSettings.heatIndexOff),
					auto_speed: this.autoControlSettings.speed
				};
				this.writeBLECharacteristicValue(command);
			},

			// 更新自动控制设置
			updateAutoControlSettings() {
				if (this.autoControlEnabled) {
					const command = {
						command: 7,
						auto_enabled: true,
						heat_index_on: parseFloat(this.autoControlSettings.heatIndexOn),
						heat_index_off: parseFloat(this.autoControlSettings.heatIndexOff),
						auto_speed: this.autoControlSettings.speed
					};
					this.writeBLECharacteristicValue(command);
				}
			},

			// 自动控制风速变化
			onAutoSpeedChange(e) {
				this.autoControlSettings.speed = parseInt(e.detail.value) + 1;
				this.updateAutoControlSettings();
			}
		}
	};
</script>

<style>
.schedule-form {
	padding: 20rpx;
}

.form-item {
	margin-bottom: 20rpx;
}

.form-item text {
	display: block;
	margin-bottom: 10rpx;
	font-size: 28rpx;
	color: #333;
}

.picker-value {
	height: 80rpx;
	line-height: 80rpx;
	padding: 0 20rpx;
	background-color: #f8f8f8;
	border-radius: 8rpx;
	font-size: 28rpx;
	color: #666;
}

/* 传感器数据样式 */
.sensor-data {
	padding: 20rpx;
}

.data-item {
	display: flex;
	align-items: center;
	margin-bottom: 20rpx;
}

.data-item .label {
	font-size: 28rpx;
	color: #333;
	width: 160rpx;
}

.data-item .value {
	font-size: 32rpx;
	color: #007AFF;
	font-weight: bold;
}

.auto-control {
	display: flex;
	align-items: center;
	margin: 30rpx 0;
	padding: 20rpx 0;
	border-top: 1px solid #eee;
}

.threshold-settings {
	margin-top: 20rpx;
	padding-top: 20rpx;
	border-top: 1px solid #eee;
}

.threshold-item {
	display: flex;
	align-items: center;
	margin-bottom: 20rpx;
}

.threshold-item input {
	width: 120rpx;
	height: 60rpx;
	border: 1px solid #ddd;
	border-radius: 8rpx;
	margin: 0 10rpx;
	text-align: center;
}

.speed-setting {
	margin-top: 20rpx;
}

.speed-setting .picker-value {
	width: 200rpx;
}
</style>
