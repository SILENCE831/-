export default {
	hostUrl: 'http://192.168.43.198:8000',  // 开发环境
	apiBaseUrl: 'http://192.168.43.198:8000',  // API基础路径
	wsUrl: 'ws://192.168.43.198:8000/ws'  // WebSocket连接地址
}