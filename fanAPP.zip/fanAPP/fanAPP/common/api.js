import config from '@/config.js';

// 创建请求拦截器
const request = (options) => {
    return new Promise((resolve, reject) => {
        // 获取token
        const token = uni.getStorageSync('token');
        
        // 合并请求头
        const header = {
            'Content-Type': 'application/json',
            ...options.header
        };
        
        // 如果有token，添加到请求头
        if (token) {
            header['Authorization'] = `Bearer ${token}`;
        }
        
        // 发起请求
        uni.request({
            url: config.apiBaseUrl + options.url,
            method: options.method || 'GET',
            data: options.data,
            header: header,
            success: (res) => {
                // 处理响应
                if (res.statusCode === 200) {
                    resolve(res.data);
                } else if (res.statusCode === 401) {
                    // token过期，清除本地存储并跳转到登录页
                    uni.removeStorageSync('token');
                    uni.removeStorageSync('userInfo');
                    uni.showToast({
                        title: '登录已过期，请重新登录',
                        icon: 'none'
                    });
                    setTimeout(() => {
                        uni.navigateTo({
                            url: '/pages/Login/Login'
                        });
                    }, 1500);
                    reject(new Error('未授权'));
                } else {
                    reject(new Error(res.data.detail || '请求失败'));
                }
            },
            fail: (err) => {
                reject(err);
            }
        });
    });
};

// API方法
export const api = {
    // 用户相关
    user: {
        login: (data) => request({
            url: '/User/Login',
            method: 'POST',
            data: {
                UserName: data.username,
                Password: data.password
            }
        }),
        register: (data) => request({
            url: '/User',
            method: 'POST',
            data: {
                UserName: data.username,
                Password: data.password
            }
        }),
        getInfo: () => request({
            url: '/User/me',
            method: 'GET'
        }),
        checkUsername: (data) => request({
            url: '/User/VerifyUser',
            method: 'POST',
            data: {
                UserName: data.username
            }
        })
    },
    
    // 设备相关
    device: {
        list: () => request({
            url: '/devices',
            method: 'GET'
        }),
        add: (data) => request({
            url: '/devices',
            method: 'POST',
            data
        }),
        update: (id, data) => request({
            url: `/devices/${id}`,
            method: 'PUT',
            data
        }),
        delete: (id) => request({
            url: `/devices/${id}`,
            method: 'DELETE'
        }),
        control: (id, data) => request({
            url: `/devices/${id}/control`,
            method: 'POST',
            data
        })
    },
    
    // WIFI相关
    wifi: {
        scan: () => request({
            url: '/wifi/scan',
            method: 'GET'
        }),
        connect: (data) => request({
            url: '/wifi/connect',
            method: 'POST',
            data
        })
    }
};

export default api;